const grupoA = 500;
const grupoB = 200;

const active = false;
const button = active && 'Botão está ativo';

console.log(button);
